# red_network_backend
This is the backend of red network store. 
The backend is made using nodeJS. Dependencies used include cores, cryptojs, dotenv,express, jsonwebtoken, mongoose, nodemon and stripe. 
It contains how users are registered using jwt, payments processing, orders processing and cart processes. 
The server is connected to a mongoDB database.
<<<<<<< HEAD
Environmental keys in the repository will not be shown.


MONGODB_URL = mongodb+srv://rednetwork:rednetwork1234@red-network.ndalmnl.mongodb.net/shop?retryWrites=true&w=majority
PASS_SEC = D0nTryToSn00p
JWT_SEC = V3RyyyPr1Vat3
STRIPE_KEY = sk_test_51KY9zsEF1Y3pMIOdYIgU9a6X1qTIm1rMipp8hM0sFrD2uG9zgZIoKM7HXLrwE8HfYFlLorNoyUc0am6L3UIZ5jKq00PjLXbbdH
=======
Environmental keys will not be shown in the repository.
>>>>>>> 585a4cf1d715015b8300aef6e04e6b2ed1b0b3b3
