import React from "react";

const Newsletter = () => {
  return <div>Newsletter</div>;
};

export default Newsletter;
