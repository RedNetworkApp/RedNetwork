import React from "react"

export const Footer = () => {
  return (
    <>
      <footer>
        <p>Copyright © Red Network all rights reserved. Powered by Red Network inc.</p>
      </footer>
    </>
  )
}
